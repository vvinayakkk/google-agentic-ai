"""Auth microservice."""
