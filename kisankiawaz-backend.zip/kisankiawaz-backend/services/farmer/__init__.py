"""Farmer microservice."""
