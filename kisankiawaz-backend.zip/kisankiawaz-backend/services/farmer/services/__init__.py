"""Farmer business-logic services."""
