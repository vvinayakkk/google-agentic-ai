"""Admin service helpers."""
